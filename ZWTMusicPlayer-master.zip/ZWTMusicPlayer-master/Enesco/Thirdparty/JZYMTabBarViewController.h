//
//  JZYMTabBarViewController.h
//  YiMian
//
//  Created by jiezi on 17/7/3.
//  Copyright © 2017年 JieZi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZYMTabBarViewController : UITabBarController

@end
