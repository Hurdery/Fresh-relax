//
//  MusicIndicator.h
//  Ting
//
//  Created by Aufree on 11/18/15.
//  Copyright © 2015 Ting. All rights reserved.
//

#import "NAKPlaybackIndicatorView.h"

@interface MusicIndicator : NAKPlaybackIndicatorView
+ (instancetype)sharedInstance;
@end
